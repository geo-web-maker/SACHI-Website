from pydantic import BaseModel, ConfigDict, Field

from app.models.common import PyObjectId


class ProgrammeImage(BaseModel):
    id: str
    caption: str
    image_url: str | None = None   # added


class ProgrammeOut(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: PyObjectId = Field(validation_alias="_id")
    slug: str
    icon: str
    num: str
    title: str
    teaser: str  # HTML, authored via the RichTextEditor
    body: str  # HTML, authored via the RichTextEditor
    images: list[ProgrammeImage]


class ProgrammeCreate(BaseModel):
    slug: str
    icon: str
    title: str
    teaser: str
    body: str
    images: list[ProgrammeImage] = []
    # num intentionally omitted — assigned server-side in the router


class ProgrammeUpdate(BaseModel):
    """Matches the fields ProgrammesAdmin.jsx actually edits: icon, teaser, body, images."""

    icon: str | None = None
    teaser: str | None = None
    body: str | None = None
    images: list[ProgrammeImage] | None = None
